﻿using System;
using System.Collections.Generic;
using FireflyCodeTest.Controllers;
using FireflyCodeTest.Models;
using NUnit.Framework;

namespace FireflyCodeTest.Tests.Controllers
{
    [TestFixture]
    public class TeacherControllerTests
    {
        [Test]
        public void TeacherNameIsNull_Test()
        {
            //Arrange
            var controller = new TeacherController();
            var classes = new List<Class>();
            var teacher = new Teacher { Classes = classes, Email = "test@test.com", Id = 1, Name = "" };

            //Assert
            Assert.Throws<ArgumentNullException>(() => controller.AddTeacher(teacher));
        }

        [Test]
        public void TeacherNameMoreThan50_Test()
        {
            //Arrange
            var controller = new TeacherController();
            var classes = new List<Class>();
            var teacher = new Teacher { Classes = classes, Email = "test@test.com", Id = 2, Name = "This name is definitely without fail longer than 50 characters I think and I hope" };

            //Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => controller.AddTeacher(teacher));
        }

        [Test]
        public void TeacherNameLessThan50_Test()
        {
            //Arrange
            var controller = new TeacherController();
            var classes = new List<Class>();
            var teacher = new Teacher { Classes = classes, Email = "test@test.com", Id = 3, Name = "Joe Bloggs" };

            //Act
            var actual = controller.AddTeacher(teacher);
            var expected = teacher;

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
