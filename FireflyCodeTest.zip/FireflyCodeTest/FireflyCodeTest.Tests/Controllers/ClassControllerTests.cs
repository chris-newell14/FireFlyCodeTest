﻿using System;
using System.Collections.Generic;
using FireflyCodeTest.Controllers;
using FireflyCodeTest.Models;
using NUnit.Framework;

namespace FireflyCodeTest.Tests.Controllers
{
    [TestFixture]
    public class ClassControllerTests
    {
        [Test]
        public void ClassNameLessThan20_Test()
        {
            //Arrange
            var controller = new ClassController();
            var students = new List<Student>();
            var schoolClass = new Class { Id = 1, Name = "Geography", Capacity = 15, Students = students, Teacher = "Mr Bloggs" };

            //Act
            var actual = controller.AddClass(schoolClass);
            var expected = schoolClass;

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void ClassNameMoreThan20_Test()
        {
            //Arrange
            var controller = new ClassController();
            var students = new List<Student>();
            var schoolClass = new Class { Id = 2, Name = "I really don't like class names that exceed 20 characters", Capacity = 15, Students = students, Teacher = "Mr Bloggs" };
           
            //Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => controller.AddClass(schoolClass));
        }

        [Test]
        public void ClassCapacityLessThan5_Test()
        {
            //Arrange
            var controller = new ClassController();
            var students = new List<Student>();
            var schoolClass = new Class { Id = 3, Name = "History", Capacity = 0, Students = students, Teacher = "Mr Bloggs" };

            //Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => controller.AddClass(schoolClass));
        }

        [Test]
        public void ClassCapacityMoreThan30_Test()
        {
            //Arrange
            var controller = new ClassController();
            var students = new List<Student>();
            var schoolClass = new Class { Id = 4, Name = "History", Capacity = 31, Students = students, Teacher = "Mr Bloggs" };

            //Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => controller.AddClass(schoolClass));
        }

        [Test]
        public void ClassCapacityInRange_Test()
        {
            //Arrange
            var controller = new ClassController();
            var students = new List<Student>();
            var schoolClass = new Class { Id = 5, Name = "History", Capacity = 25, Students = students, Teacher = "Mr Bloggs" };

            //Act
            var actual = controller.AddClass(schoolClass);
            var expected = schoolClass;

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}
