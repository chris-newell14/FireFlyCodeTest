﻿using System;
using System.Collections.Generic;
using FireflyCodeTest.Controllers;
using FireflyCodeTest.Models;
using NUnit.Framework;

namespace FireflyCodeTest.Tests.Controllers
{
    [TestFixture]
    public class StudentContollerTests
    {
        [Test]
        public void StudentNameIsNull_Test()
        {
            //Arrange
            var controller = new StudentController();
            var classes = new List<Class>();
            var student = new Student { Id = 1, Name = "", Classes = classes, Email = "test@test.com" };

            //Assert
            Assert.Throws<ArgumentNullException>(() => controller.AddStudent(student));
        }

        [Test]
        public void StudentNameMoreThan50_Test()
        {
            //Arrange
            var controller = new StudentController();
            var classes = new List<Class>();
            var student = new Student { Id = 2, Name = "This name is definitely without fail longer than 50 characters I think and I hope", Classes = classes, Email = "test@test.com" };

            //Assert
            Assert.Throws<ArgumentOutOfRangeException>(() => controller.AddStudent(student));
        }

        [Test]
        public void StudentNameLessThan50_Test()
        {
            //Arrange
            var controller = new StudentController();
            var classes = new List<Class>();
            var student = new Student { Id = 2, Name = "Chris Newell", Classes = classes, Email = "test@test.com" };

            //Act
            var actual = controller.AddStudent(student);
            var expected = student;

            //Assert
            Assert.AreEqual(expected, actual);
        }
    }
}