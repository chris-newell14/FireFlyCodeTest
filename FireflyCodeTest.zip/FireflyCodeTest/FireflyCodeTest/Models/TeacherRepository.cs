﻿using System;
using System.Collections.Generic;
namespace FireflyCodeTest.Models
{
    public class TeacherRepository : ITeacherRepository
    {
        private List<Teacher> teachers = new List<Teacher>();
        private List<Class> classes = new List<Class>();
        private int teacherId = 1;  
        public TeacherRepository()  
        {  
            //AddTeacher(new Teacher { Id = 1, Name = "Chris", Email = "test@test.com", Classes = classes });  
           // AddTeacher(new Teacher { Id = 2, Name = "Joe", Email = "Joe.bloggs@test.com", Classes = classes });  
        }  
   
        public IEnumerable<Teacher> GetAllTeachers()  
        {  
            return teachers;  
        }  
   
        public Teacher AddTeacher(Teacher teacher)  
        {  
            if (teachers == null)  
            {  
                throw new ArgumentNullException("No teacher list avaliable.");  
            }  
   
            teacher.Id = teacherId++;  
            teachers.Add(teacher);  
            return teacher;  
        }  
    }
}
