﻿using System;
using System.Collections.Generic;

namespace FireflyCodeTest.Models
{
    public interface ITeacherRepository
    {
        IEnumerable<Teacher> GetAllTeachers();
        Teacher AddTeacher(Teacher teacher);
    }
}
