﻿using System;
using System.Collections.Generic;
namespace FireflyCodeTest.Models
{
    public class Class
    {
        public int Id { get; set; }
        public string Name { get; set; } 
        public List<Student> Students { get; set; } 
        public int Capacity { get; set; } 
        public string Teacher { get; set; } 
    }
}
