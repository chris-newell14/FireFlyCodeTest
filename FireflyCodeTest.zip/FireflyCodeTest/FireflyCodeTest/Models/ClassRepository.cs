﻿using System;
using System.Collections.Generic;

namespace FireflyCodeTest.Models
{
    public class ClassRepository: IClassRepository
    {
        private List<Class> classes = new List<Class>();
        private int classId = 1;
        public ClassRepository()
        {
             
        }

        public IEnumerable<Class> GetAllClasses()
        {
            return classes;
        }

        public Class AddClass(Class schoolClass)
        {
            if (classes == null)
            {
                throw new ArgumentNullException("No student list avaliable.");
            }

            schoolClass.Id = classId++;
            classes.Add(schoolClass);
            return schoolClass;
        }
    }
}
