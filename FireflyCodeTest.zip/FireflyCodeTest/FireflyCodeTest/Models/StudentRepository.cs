﻿using System;
using System.Collections.Generic;
namespace FireflyCodeTest.Models
{
    public class StudentRepository : IStudentRepository
    {
        private List<Student> students = new List<Student>();
        private int studentId = 1;  
        public StudentRepository()  
        {  
            //AddStudent(new Student { Id = 1, Name = "Chris", Email = "test@test.com", Classes = classes });  
           // AddStudent(new Student { Id = 2, Name = "Joe", Email = "Joe.bloggs@test.com", Classes = classes });  
        }  
   
        public IEnumerable<Student> GetAllStudents()  
        {  
            return students;  
        }  
   
        public Student AddStudent(Student student)  
        {  
            if (students == null)  
            {  
                throw new ArgumentNullException("No student list avaliable.");  
            }  
   
            student.Id = studentId++;  
            students.Add(student);  
            return student;  
        }  
    }
}
