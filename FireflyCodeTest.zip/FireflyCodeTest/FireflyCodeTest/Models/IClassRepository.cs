﻿using System;
using System.Collections.Generic;
namespace FireflyCodeTest.Models
{
    public interface IClassRepository
    {
        IEnumerable<Class> GetAllClasses();  
        Class AddClass(Class schoolClass); 
    }
}
