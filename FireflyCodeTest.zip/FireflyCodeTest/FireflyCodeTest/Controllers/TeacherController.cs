﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FireflyCodeTest.Models;

namespace FireflyCodeTest.Controllers
{
    public class TeacherController : Controller
    {
        static readonly ITeacherRepository teacherRepository = new TeacherRepository();

        public IEnumerable<Teacher> GetAll()
        {
            return teacherRepository.GetAllTeachers();
        }

        public Teacher AddTeacher(Teacher teacher)
        {
            if (string.IsNullOrEmpty(teacher.Name))
            {
                throw new ArgumentNullException("A teacher must have a name");
            }

            if (teacher.Name.Length > 50)
            {
                throw new ArgumentOutOfRangeException("Teacher name cannot be more than 50 characters");
            }

            return teacherRepository.AddTeacher(teacher);
        }

        public Class AssignClass(int classId, string teacherName)
        {
            //Get the class from the provided class Id
            var classController = new ClassController();
            var schoolClass = classController.GetAll().FirstOrDefault(c => c.Id == classId);

            //Assign provided teacher to retrieved school class
            var teacher = GetAll().FirstOrDefault(t => t.Name == teacherName);

            if(!string.IsNullOrEmpty(schoolClass.Teacher))
            {
                throw new ArgumentOutOfRangeException("There is already a teacher assigned to this class!");
            }

            if (teacher.Classes.Count + 1 > 5)
            {
                throw new ArgumentOutOfRangeException("Teacher is already assigned to 5 classes");
            }

            schoolClass.Teacher = teacherName;
            teacher.Classes.Add(schoolClass);

            return schoolClass;      
        }
    }
}
