﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using FireflyCodeTest.Models;

namespace FireflyCodeTest.Controllers
{
    public class StudentController : Controller
    {
        static readonly IStudentRepository studentRepository = new StudentRepository();

        public IEnumerable<Student> GetAll()
        {
            return studentRepository.GetAllStudents();
        }

        public Student AddStudent(Student student)
        {
            if (string.IsNullOrEmpty(student.Name))
            {
                throw new ArgumentNullException("A student must have a name");
            }

            if (student.Name.Length > 50)
            {
                throw new ArgumentOutOfRangeException("Student name cannot be more than 50 characters");
            }

            return studentRepository.AddStudent(student);
        }
    }
}
