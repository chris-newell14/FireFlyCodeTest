﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FireflyCodeTest.Models;

namespace FireflyCodeTest.Controllers
{
    public class ClassController : Controller
    {
        static readonly IClassRepository classRepository = new ClassRepository();

        public IEnumerable<Class> GetAll()
        {
            return classRepository.GetAllClasses();
        }

        public Class AddClass(Class schoolClass)
        {
            if(string.IsNullOrEmpty(schoolClass.Name))
            {
                throw new ArgumentNullException("A class must have a name");
            }

            if(schoolClass.Name.Length > 20)
            {
                throw new ArgumentOutOfRangeException("Class name cannot be more than 20 characters");
            }

            if (schoolClass.Capacity < 5 || schoolClass.Capacity > 30)
            {
                throw new ArgumentOutOfRangeException("Class capacity cannot be less than 5 or more than 30");
            }

            return classRepository.AddClass(schoolClass);
        }

        public Class EnrollStudent(int classId, Student student)
        {
            //Get the selected class
            var schoolClass = GetAll().FirstOrDefault(c => c.Id == classId);

            //Add the student to the student class list and reassign the new list back to the class
            var studentClassList = schoolClass.Students;

            if(studentClassList.Count + 1 > schoolClass.Capacity)
            {
                //Class has exceeded its capacity. Throw exception
                throw new ArgumentOutOfRangeException("Cannot add student to class. Class is already at capacity!");
            }

            studentClassList.Add(student);
            schoolClass.Students = studentClassList;

            return schoolClass;
        }
    }
}
